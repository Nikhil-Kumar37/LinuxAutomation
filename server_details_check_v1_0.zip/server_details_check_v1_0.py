"""
        .SYNOPSIS
        Server Details Check

        .DESCRIPTION
        Script will validate the details of servers and print output in JSON format.

        Task performs :

        1. Collect input from CMD line
        2. Validation of the details of server
        3. JSON output print


        .INPUTS
        Inputs will be taken from the CMD line.

        Required inputs :
        1. serial_Input
        2. csv_File

        .OUTPUT
        Output will give status of server and all details in JSON format.

        .MODULES USED :
         1. pandas
         2. os
         3. json
         4. sys

        .EXAMPLE

        PS D:\> python server_details_check_v1_0.py sn1003 C:\servers.csv

        Script Name    : server_details_check_v1_0.py
        Script Version : 1.0
        Author         : Nikhil Kumar
        Creation Date  : 15 July 2021

"""

## Scripts starts here ##

print("Script execution started.")

#!/usr/bin/env python

## Importing required modules ##

import pandas as pd
import os
import json
import sys

## Try block ##

try:

    ## Reading inputs ##

    serial_Input = sys.argv[0]
    csv_File = sys.argv[1]

    ## Reading input file ##

    file_data = pd.read_csv(csv_File)


    axis = 0
    final_json = {}

    for i in file_data['serial']:

        if str(i.strip()) == serial_Input and file_data['serial'][axis] == serial_Input:

            print("Serial number is present in file.")

            ## Collecting details ##
            
            ip_addr = file_data['ip'][axis]
            ip_address = ip_addr.strip()

            ## Ping test ##
            
            ping_Output = os.popen("ping -n 1 {0}".format(ip_address)
            
                if "0% loss" in ping_Output:

                    print("Server is reachable.")
                    serial_value.strip() = file_data['serial'][axis]
                    final_json['serial'] = serial_value
                    hostname_value.strip() = file_data['hostname'][axis]
                    final_json['hostname'] = hostname_value
                    final_json['ip'] = ip_address
                    netmask_value.strip() = file_data['netmask'][axis]
                    final_json['netmask'] = netmask_value
                    gateway_value.strip() = file_data['gateway'][axis]
                    final_json['gateway'] = gateway_value
                    final_json['ping status'] = "reachable."
                
                else:

                    print("Server is not reachable.")
                    serial_value.strip() = file_data['serial'][axis]
                    final_json['serial'] = serial_value
                    hostname_value.strip() = file_data['hostname'][axis]
                    final_json['hostname'] = hostname_value
                    final_json['ip'] = ip_address
                    netmask_value.strip() = file_data['netmask'][axis]
                    final_json['netmask'] = netmask_value
                    gateway_value.strip() = file_data['gateway'][axis]
                    final_json['gateway'] = gateway_value
                    final_json['ping status'] = "not reachable."
                
        else:

            print("Server is not reachable.")
            final_json['serial'] = "Bad request." 
        
        axis += 1

    final_Output = json.dumps(final_json, indent = 4)
    print(final_Output)
    print("Script execution completed.")

## Except block ##

except Exception as err:

    err_output = err
    error_output = "Script failed to check the details.\n Error - {}.\n".format(err_output)
    print(error_output)

## Script ends here ##